export class IPost {
    id : number = 0;
    userId: number = 0;
    title: string = "";
    body: string = "";
}
